from __future__ import absolute_import

from .Array import *
from .ArrayQueue import *
from .ArrayStack import *
from .AVLTree import *
from .AVLTreeMap import *
from .AVLTreeSet import *
from .BST import *
from .BSTMap import *
from .BSTSet import *
from .HashMap import *
from .HashSet import *
from .HashTable import *
from .IndexMaxHeap import *
from .IndexMinHeap import *
from .LinkedList import *
from .LinkedListMap import *
from .LinkedListQueue import *
from .LinkedListSet import *
from .LinkedListStack import *
from .LoopQueue import *
from .MaxHeap import *
from .MinHeap import *
from .PriorityQueue import *
from .RBTree import *
from .SegmentTree import *
from .Trie import *
from .UF import *
from .UFQuickFind import *

__version__='0.0.1'
__license__=''

name = "basicds"